# NITRAM SUPERMARKET POS — Tauri + SQLite migration project

## What this is
A Windows desktop migration project retaining the existing POS HTML/JavaScript interface and moving its synchronous save/load contract to a local SQLite database service. The database lives in the Windows per-user application data directory, not Firefox storage.

## Durability design
- SQLite WAL journal mode.
- `synchronous=FULL` for durable transaction commits.
- Existing POS `save()` serializes the state and makes a synchronous loopback request. It returns only after SQLite commits and responds with a revision.
- The POS startup checks SQLite integrity and refuses to expose the app if the database service is unavailable.
- Database writes are transactional.
- JSON backup export/import and database reset controls are provided in the application shell; import preserves a pre-import database copy.
- A random bearer token protects the loopback service. The listener binds only to 127.0.0.1.

## Windows build
Requirements: Windows 10/11, Rust stable, Node.js, Microsoft C++ Build Tools (C++ workload and Windows SDK).
Run PowerShell as a normal user and execute `BUILD_WINDOWS.ps1`.
The Tauri installer bundles should appear under `src-tauri/target/release/bundle/`.

## First launch and migration
The app seeds the bundled ROBIPOS catalogue when the SQLite database is empty.
Use **Import backup** to import a JSON state backup from the old POS, if one can still be recovered. **Export backup** creates a portable full-state JSON file.
Keep the old POS and all old backup files until the new desktop app has been tested and reconciled.

## Important test status
This package is application source, not a compiled Windows installer. It has not been compiled or run on the target Windows PC in this environment. JavaScript syntax, ZIP integrity, and the database design can be checked here; actual Windows build, scanner, Xprinter, data migration, Firefox-independent restart, and power-interruption tests must be completed on the target PC before production use.

## Supabase roadmap
The local storage boundary is isolated behind a `NITRAM_STORAGE` API. The current initial migration stores the complete POS state as one transactional JSON document to preserve existing behaviour. This is a transitional persistence layer, not yet a normalized multi-terminal sync implementation. Next engineering step: normalize products, sales, sale items, stock movements, shifts, expenses, supplier records and users into SQLite tables; add a transactional outbox and idempotent sync worker for Supabase PostgreSQL. Never place a Supabase service-role key in the desktop client.
