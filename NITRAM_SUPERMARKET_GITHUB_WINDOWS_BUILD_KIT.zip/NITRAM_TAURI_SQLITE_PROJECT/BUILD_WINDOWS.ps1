$ErrorActionPreference = "Stop"
Write-Host "NITRAM SUPERMARKET POS - Windows desktop build" -ForegroundColor Green
Write-Host "Prerequisites: Rust stable, Node.js, and Microsoft C++ Build Tools."
Set-Location "$PSScriptRoot\src-tauri"
cargo install tauri-cli --version "^2" --locked
cargo tauri build
Write-Host "Build complete. Look in src-tauri\target\release\bundle\msi and nsis." -ForegroundColor Green
