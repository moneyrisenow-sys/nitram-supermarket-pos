#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
use rusqlite::{params, Connection, OptionalExtension};
use serde::Serialize;
use std::{io::Read, net::{TcpListener,TcpStream}, path::PathBuf, thread, time::Duration};
use tiny_http::{Header, Method, Response, Server};
use uuid::Uuid;
use tauri::Manager;

#[derive(Clone)]
struct DbConfig { path: PathBuf, token: String, port: u16 }
#[derive(Serialize)]
struct StorageInfo { port: u16, token: String }

fn open_db(path:&PathBuf)->Result<Connection,String>{
 let c=Connection::open(path).map_err(|e|e.to_string())?;
 c.pragma_update(None,"journal_mode","WAL").map_err(|e|e.to_string())?;
 c.pragma_update(None,"synchronous","FULL").map_err(|e|e.to_string())?;
 c.pragma_update(None,"foreign_keys","ON").map_err(|e|e.to_string())?;
 c.busy_timeout(Duration::from_secs(10)).map_err(|e|e.to_string())?;
 c.execute_batch("CREATE TABLE IF NOT EXISTS pos_state(id INTEGER PRIMARY KEY CHECK(id=1), state_json TEXT NOT NULL, revision INTEGER NOT NULL, updated_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS sync_outbox(id TEXT PRIMARY KEY, entity TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL, synced_at TEXT);
 CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
 INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(1,datetime('now'));").map_err(|e|e.to_string())?;
 Ok(c)
}
fn response(req:tiny_http::Request, status:u16, body:String, content_type:&str, origin:&str){
 let mut headers=vec![
  Header::from_bytes("Content-Type",content_type).unwrap(),
  Header::from_bytes("Access-Control-Allow-Origin",origin).unwrap(),
  Header::from_bytes("Access-Control-Allow-Headers","Authorization, Content-Type").unwrap(),
  Header::from_bytes("Access-Control-Allow-Methods","GET, POST, DELETE, OPTIONS").unwrap(),
  Header::from_bytes("Cache-Control","no-store").unwrap()
 ];
 let code=tiny_http::StatusCode(status);
 let _=req.respond(Response::from_string(body).with_status_code(code).with_headers(headers.drain(..)));
}
fn run_server(cfg:DbConfig){
 let addr=format!("127.0.0.1:{}",cfg.port);
 let server=Server::http(&addr).expect("local POS database server must bind");
 for mut req in server.incoming_requests(){
  let origin=req.headers().iter().find(|h|h.field.equiv("Origin")).map(|h|h.value.as_str().to_string()).unwrap_or_default();
  let safe_origin=if origin.starts_with("http://tauri.localhost")||origin.starts_with("https://tauri.localhost")||origin.starts_with("http://localhost") {"*"} else {"null"};
  if req.method()==&Method::Options {response(req,204,String::new(),"text/plain",safe_origin);continue;}
  let auth=req.headers().iter().find(|h|h.field.equiv("Authorization")).map(|h|h.value.as_str().to_string()).unwrap_or_default();
  if auth!=format!("Bearer {}",cfg.token){response(req,401,"Unauthorized".into(),"text/plain",safe_origin);continue;}
  let path=req.url().split('?').next().unwrap_or("/");
  match (req.method(),path){
   (&Method::Get,"/health")=>{
    let result=open_db(&cfg.path).and_then(|c|c.query_row("PRAGMA integrity_check",[],|r|r.get::<_,String>(0)).map_err(|e|e.to_string()));
    match result {Ok(v) if v=="ok"=>response(req,200,"{\"ok\":true,\"database\":\"healthy\"}".into(),"application/json",safe_origin),Ok(v)=>response(req,500,format!("{{\"ok\":false,\"detail\":\"{}\"}}",v),"application/json",safe_origin),Err(e)=>response(req,500,e,"text/plain",safe_origin)}
   }
   (&Method::Get,"/state")=>{
    let result=open_db(&cfg.path).and_then(|c|c.query_row("SELECT state_json FROM pos_state WHERE id=1",[],|r|r.get::<_,String>(0)).optional().map_err(|e|e.to_string()));
    match result {Ok(Some(v))=>response(req,200,v,"application/json",safe_origin),Ok(None)=>response(req,200,"null".into(),"application/json",safe_origin),Err(e)=>response(req,500,e,"text/plain",safe_origin)}
   }
   (&Method::Delete,"/state")=>{
    let result=open_db(&cfg.path).and_then(|c|c.execute("DELETE FROM pos_state WHERE id=1",[]).map_err(|e|e.to_string()));
    match result {Ok(_)=>response(req,200,"{\\"ok\\":true}".into(),"application/json",safe_origin),Err(e)=>response(req,500,e,"text/plain",safe_origin)}
   }
   (&Method::Post,"/state")|(&Method::Post,"/import")=>{
    let importing=path=="/import";let mut body=String::new();
    if let Err(e)=req.as_reader().read_to_string(&mut body){response(req,400,e.to_string(),"text/plain",safe_origin);continue;}
    if serde_json::from_str::<serde_json::Value>(&body).is_err(){response(req,400,"Invalid JSON state".into(),"text/plain",safe_origin);continue;}
    let result=(||->Result<i64,String>{
     let mut c=open_db(&cfg.path)?;
     let tx=c.transaction().map_err(|e|e.to_string())?;
     if importing {
      tx.execute("INSERT INTO pos_state(id,state_json,revision,updated_at) VALUES(1,?1,1,datetime('now')) ON CONFLICT(id) DO UPDATE SET state_json=excluded.state_json,revision=pos_state.revision+1,updated_at=excluded.updated_at",params![body]).map_err(|e|e.to_string())?;
     } else {
      tx.execute("INSERT INTO pos_state(id,state_json,revision,updated_at) VALUES(1,?1,1,datetime('now')) ON CONFLICT(id) DO UPDATE SET state_json=excluded.state_json,revision=pos_state.revision+1,updated_at=excluded.updated_at",params![body]).map_err(|e|e.to_string())?;
     }
     let rev=tx.query_row("SELECT revision FROM pos_state WHERE id=1",[],|r|r.get::<_,i64>(0)).map_err(|e|e.to_string())?;
     tx.commit().map_err(|e|e.to_string())?;
     c.execute_batch("PRAGMA wal_checkpoint(PASSIVE);").map_err(|e|e.to_string())?;
     Ok(rev)
    })();
    match result {Ok(rev)=>response(req,200,format!("{{\"ok\":true,\"revision\":{}}}",rev),"application/json",safe_origin),Err(e)=>response(req,500,e,"text/plain",safe_origin)}
   }
   _=>response(req,404,"Not found".into(),"text/plain",safe_origin)
  }
 }
}
#[tauri::command]
fn storage_info(state:tauri::State<'_,DbConfig>)->StorageInfo{StorageInfo{port:state.port,token:state.token.clone()}}
fn main(){
 tauri::Builder::default().setup(|app|{
  let mut path=app.path().app_data_dir()?;std::fs::create_dir_all(&path)?;path.push("nitram-pos.sqlite3");
  open_db(&path).map_err(std::io::Error::other)?;
  let listener=TcpListener::bind("127.0.0.1:0")?;let port=listener.local_addr()?.port();drop(listener);
  let cfg=DbConfig{path,token:Uuid::new_v4().to_string(),port};
  let server_cfg=cfg.clone();thread::spawn(move||run_server(server_cfg));
  // Do not let the webview bootstrap race the background database listener.
  let ready_addr=format!("127.0.0.1:{}",port);
  let mut ready=false;
  for _ in 0..100 {
   if TcpStream::connect(&ready_addr).is_ok(){ready=true;break;}
   thread::sleep(Duration::from_millis(20));
  }
  if !ready{return Err(std::io::Error::new(std::io::ErrorKind::TimedOut,"Local database service did not start").into());}
  app.manage(cfg);
  Ok(())
 }).invoke_handler(tauri::generate_handler![storage_info])
 .run(tauri::generate_context!()).expect("error while running NITRAM POS");
}
